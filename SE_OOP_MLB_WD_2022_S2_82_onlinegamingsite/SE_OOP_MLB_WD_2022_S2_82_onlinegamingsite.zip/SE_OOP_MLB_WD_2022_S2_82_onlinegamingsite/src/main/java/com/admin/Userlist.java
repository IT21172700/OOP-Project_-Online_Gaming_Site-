package com.admin;

public class Userlist {
	
	private String name;
	private String password;
	private String phone;
	private String email;

	
	//creating the constructor for variables
	public Userlist(String name, String password, String phone, String email) {
		this.name = name;
		this.password = password;
		this.phone = phone;
		this.email = email;
	}
	

	public String getname() {
		return name;
	}

	public String getpassword() {
		return password;
	}

	public String getphone() {
		return phone;
	}	

	public String getemail() {
		return email;
	}

}
