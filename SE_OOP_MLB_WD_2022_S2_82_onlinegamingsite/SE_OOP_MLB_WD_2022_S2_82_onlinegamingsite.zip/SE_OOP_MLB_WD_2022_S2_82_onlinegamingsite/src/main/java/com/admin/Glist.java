package com.admin;

public class Glist {

	
	private String name;
	private String details;
	private String type;
	private String devName;

	
	//creating the constructor for variables
	public Glist(String name, String details, String type, String devName) {
		this.name = name;
		this.details = details;
		this.type = type;
		this.devName = devName;
	}
	

	public String getname() {
		return name;
	}

	public String getpassword() {
		return details;
	}

	public String getphone() {
		return type;
	}	

	public String getemail() {
		return devName;
	}
}
